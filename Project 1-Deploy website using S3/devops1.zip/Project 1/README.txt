***************************************
Project: Deploy Static Website on AWS
--by Zadok Joshua
***************************************
Summary:
This project is my foremost project of the Cloud DevOps Nanodegree course. 
The aim of the project is to know how to host a static website using an 
AWS S3 bucket that includes HTML, CSS, and JavaScript files. Futhermore, I learnt
how to use Amazon CloudFront-a content delivery network used to deliver applications
globally.

Website URL: d3ivtoq8wahrvx.cloudfront.net

Note:
I changed the original image of the vacation photo and the change some text. 
The full screenshot of the website is 'TheProduct.png'.
***************************************
Thank you.